document.getElementById("open-sidebar").addEventListener("click", () => {
    // Inject the sidebar into the current tab
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        files: ["content.js"]
      });
    });
  });
  